Baxter Ratings v1 Complete Package

Coverage: 2006-2011, 2024, 2025.

The master workbook contains the complete metrics pattern and year-by-year ratings.
All reported frozen-spec results use ridge lambda 0.3. The season-best lambda column is diagnostic and reflects the lowest-MAE sensitivity result.
2024-2025 modern ratings in the master workbook use the joint frozen specification.
2010 classification correction: TCU is FCS in the synthetic 2010 universe and is excluded from FBS leaderboard interpretation.
Raw rating scales are season-specific and are not directly comparable across seasons.
