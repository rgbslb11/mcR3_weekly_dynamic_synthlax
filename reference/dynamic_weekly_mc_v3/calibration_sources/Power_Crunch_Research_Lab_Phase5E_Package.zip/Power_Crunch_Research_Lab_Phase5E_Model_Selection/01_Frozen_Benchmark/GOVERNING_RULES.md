# Governing Rules

- Every 2024 and 2025 listed team is an official synthetic FBS member.
- Every game in the certified season ledgers is official synthetic data.
- ECL is a full FBS conference.
- Independent means no conference; independents are not conference-champion eligible.
- Pac-12 is a valid conference but has no conference champion.
- Delaware joined CUSA permanently beginning in 2025.
- Southern Miss moved intentionally and permanently to the American beginning in 2025.
- 2024 synthetic-only games without exact dates use week and source sequence; dates are not inferred.
- 2025 is the untouched forward-validation season for models calibrated on 2024.
- No 2026 canonical-model changes are authorized.
