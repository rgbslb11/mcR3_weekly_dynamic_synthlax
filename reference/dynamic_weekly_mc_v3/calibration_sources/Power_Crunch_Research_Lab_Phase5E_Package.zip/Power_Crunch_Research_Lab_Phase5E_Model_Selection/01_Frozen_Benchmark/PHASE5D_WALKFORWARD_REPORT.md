# Phase 5D — Chronological Synthetic FBS Walk-Forward Validation

## Scope
All 1,481 games in 2024-2025 were treated as official synthetic FBS contests. 2024 contains 724 games and 2025 contains 757.

## Chronology
- 2024: exact date where source-supported; otherwise verified week and source sequence.
- 2025: source date and locked workbook row order.
- Predictions were calculated before each game result updated team state.

## Primary untouched 2025 result
Best probability model by Brier score: **p_modern_multifeature**.
- Accuracy: 0.659
- Brier: 0.2112
- Log loss: 0.6087
- AUC: 0.720
- Margin MAE: 17.24
- Margin RMSE: 21.73

## Q4 transfer
Best untouched 2025 Q4 model by Brier score: **p_q4_historical_transfer**.
- Cases: 732
- Comeback rate: 0.117
- Brier: 0.0931
- Log loss: 0.2834
- AUC: 0.834

## Interpretation
The framework is complete for a two-season modern synthetic universe. It is not a continuous 2006-2025 model because 2012-2023 is absent. Historical calibration and modern calibration are retained as separate candidates, and 2025 is preserved as the forward test.

## Remaining blocks
1. 2012-2023 source gap.
2. 2026 integration remains prohibited without explicit authorization.
3. Exact kickoff timestamps are unavailable for 174 official synthetic 2024 games; this is non-blocking for week-sequenced research.
