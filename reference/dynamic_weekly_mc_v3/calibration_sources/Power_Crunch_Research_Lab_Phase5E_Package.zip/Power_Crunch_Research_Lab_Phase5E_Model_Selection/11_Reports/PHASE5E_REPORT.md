# Phase 5E — Model Selection, Stability, and 2026 Shadow

## Governance
Phase 5D was frozen before post-benchmark tuning. No 2026 canonical data were modified.

## Chronology
Source-order, week-batch, and 100 randomized within-week variants were tested. See chronology_sensitivity_summary.csv.

## Carryover
Carryover was selected only on 2025 Weeks 1-4 from the grid [0, 0.1, 0.2, 0.3, 0.35, 0.4, 0.5, 0.6, 0.75, 1.0]. Selected value: 100%. Its Weeks 5+ metrics are recorded separately.

## Selected research architecture
- Probability: dynamic_conf (fixed conference-label models rejected by governance despite lower test Brier)
- Margin: huber
- Q4: historical transfer
- Uncertainty: 10th-90th quantile gradient-boost interval
- Status: research candidate, not canonical

## 2026 shadow
Generated 736 schedule-level research probabilities. Canonical per-game probabilities were unavailable; canonical power differences are preserved as a comparison field. Unresolved team-code mappings: 0.

## Blocks
1. Canonical per-game probabilities are not present in the supplied board.
2. 2026 outcomes do not yet exist.
3. 2024 exact within-week kickoff ordering remains unavailable for 174 games, but sensitivity is measured and non-blocking.
