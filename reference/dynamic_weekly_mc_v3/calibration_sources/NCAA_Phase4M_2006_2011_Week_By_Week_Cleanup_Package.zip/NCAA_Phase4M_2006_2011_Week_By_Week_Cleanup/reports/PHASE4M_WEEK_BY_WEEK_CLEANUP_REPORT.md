# Phase 4M — 2006–2011 Week-by-Week Chronology Cleanup

## Scope and ruling

This package consolidates the source-derived chronological sequence, week, and date fields for all synthetic games from 2006 through 2011. Raw source date text is preserved. Normalized dates are added only under explicit, auditable rules. No external or real-world schedule was used.

## Coverage

| Season | Games | Week available | Date available | Sequence available | Unresolved week | Unresolved date |
|---:|---:|---:|---:|---:|---:|---:|
| 2006 | 536 | 517 | 493 | 536 | 19 | 43 |
| 2007 | 527 | 519 | 506 | 527 | 8 | 21 |
| 2008 | 624 | 592 | 559 | 624 | 32 | 65 |
| 2009 | 625 | 582 | 558 | 625 | 43 | 67 |
| 2010 | 642 | 572 | 546 | 642 | 70 | 96 |
| 2011 | 713 | 675 | 675 | 713 | 38 | 38 |

## 2006–2007 cleanup rules

1. The original source text remains unchanged in `raw_source_date_text`.
2. 2007 headers carrying `/06` are normalized to 2007 only when the stated weekday exactly matches that month/day in 2007.
3. 2006 Week 6 date labels that repeat Week 4 are normalized to the next Thursday/Friday/Saturday between Week 5 and Week 7; the correction is explicitly flagged.
4. An unmatched game receives a cleaned date only when it is bounded by dated games on both sides with the same week and same cleaned date.
5. Games without sufficient evidence retain sequence only or week only.

## 2008–2011 location

The week-by-week fields already existed inside the Phase 4H calibration base but had not been surfaced as standalone season tables. They are now exported under `data/by_season/2008_week_by_week.csv` through `2011_week_by_week.csv`, and in the combined 2006–2011 table.

## Governance

These changes improve historical chronology only. They do not modify the 2026 canonical model.
