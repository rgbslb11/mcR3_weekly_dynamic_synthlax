# INPUTS — Operation Silent Fall 2024 (Source Lineage)

Immutable inputs and their SHA-256 hashes. Reality flows one direction:
raw source → derived inputs → build. Recorded 2026-07-11.

## Source of truth

| Input | SHA-256 |
|---|---|
| Source PDF — sports-reference.com 2024 schedule & results (`College_Football_Schedule__Scores_and_Results-_2024___College_Football_at_Sports.pdf`) | `1eb7c37fce764fcdc7be2861b064a1f3ab1ba302c7be147f9374d3bb89aef1ca` |
| `data/raw/2024_real.csv` (864 real regular-season games, home/away derived) | `44a5f585f10378d5f960e079fbda5dc1d5886197cc9b4388d85a577cb479cc66` |
| `registry/teams_2024.csv` (118 teams) | `f4c3114178eebec50d8a2912613a15bfd5a831e6dfe6131b944cea161472fb97` |
| `registry/conferences_2024.csv` | `8db7b89aa935c75556d3fede6048390d727aa273eea9bffd2f2f4b6d621b9948` |
| `registry/crosswalk_2024.csv` (SR name → team_id; ECL → OUT) | `0302404cd300ec5b13c67e569cabbe22fd54cb152d83cbbdfc0e54c2ba230a22` |

## Derivation chain

```
SOURCE_PDF
  └─ pdftotext -layout ─────────────────► /tmp/sched.txt   (ephemeral)
       └─ parse_sr_schedule.py ─────────► data/raw/2024_real.csv        (864 games)
            └─ import_real.py + crosswalk ► data/interim/slate_real_2024.csv (550 anchored)
                 └─ assemble_slate.py ────► data/interim/slate_full_2024.csv (708 games)
                      └─ compute_strength / score_synth / simulate_season ► champion
```

## Notes

- Facts only: game results (teams, dates, scores) are uncopyrightable facts extracted
  from the source and reshaped; no editorial content reproduced.
- The PDF lives in the uploads mount (read-only); its hash above pins the exact source
  used. Re-running `parse_sr_schedule.py` on the same PDF reproduces `2024_real.csv`.
- Output hashes are tracked separately in `artifacts/release/RELEASE_MANIFEST.json`.
- ECL's 8 teams are `OUT` in the crosswalk (real FCS → do not anchor under R2), even
  though they are in-universe FBS-by-fiat.
